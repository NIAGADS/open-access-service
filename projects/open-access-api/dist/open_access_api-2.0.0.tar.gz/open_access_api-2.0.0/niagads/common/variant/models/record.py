"""variant annotator functions"""

from typing import Any, Dict, List, Optional

from niagads.common.genomic.regions.models import OneBasedGenomicRegion
from niagads.common.models.base import CustomBaseModel
from niagads.common.models.types import Range
from niagads.common.variant.models.ga4gh_vrs import Allele
from niagads.common.variant.types import VariantClass
from niagads.genome_reference.human import HumanGenome
from niagads.utils.regular_expressions import RegularExpressions
from pydantic import AliasChoices, Field, model_validator

# TODO: add ga4gh to variant identifier (optional? maybe)


class VariantIdentifier(CustomBaseModel):
    ref_snp_id: Optional[str] = Field(
        default=None, pattern=RegularExpressions.REF_SNP_ID
    )
    id: str = Field(
        pattern=RegularExpressions.POSITIONAL_VARIANT_ID
        + "|"
        + RegularExpressions.STRUCTUAL_VARIANT_ID,
        description="stable NIAGADS variant ID",
    )


class VariantRecord(VariantIdentifier):
    chromosome: HumanGenome = Field(..., title="Chromosome")
    position: int = Field(
        ...,
        description="1-based position of the variant on the chromosome",
        title="Position",
    )
    length: Optional[int] = Field(
        default=None, description="Length of the variant (in bases)", title="Length"
    )
    ref: str = Field(
        ...,
        validation_alias=AliasChoices("ref", "ref_allele"),
        description="Reference allele sequence",
        title="Reference Allele",
    )
    alt: str = Field(
        ...,
        validation_alias=AliasChoices("alt", "alt_allele"),
        description="Alternate allele sequence",
        title="Alternate Allele",
    )
    variant_class: VariantClass = Field(
        default=None,
        description="Variant class (e.g., SNV, INDEL, SV)",
        title="Variant Class",
    )

    ga4gh_vrs: Optional[Allele] = Field(
        default=None,
        description="GA4GH VRS Allele object representation",
        title="GA4GH VRS Allele",
    )

    positional_id: Optional[str] = Field(
        default=None,
        description="Positional variant identifier (chrom:pos:ref:alt)",
        title="Positional ID",
    )
    normalized_positional_id: Optional[str] = Field(
        default=None,
        pattern=RegularExpressions.NORMALIZED_POSITIONAL_VARIANT_ID,
        description="Normalized positional variant identifier",
        title="Normalized Positional ID",
    )
    hgvs: Optional[str] = Field(
        default=None,
        title="HGVS",
        description="HGVS representation of the variant",
    )
    is_adsp_variant: Optional[bool] = Field(
        default=None,
        title="Is ADSP Variant?",
        description="indicates whether the variant is present in ADSP data",
    )
    is_structural_variant: Optional[bool] = Field(
        default=None,
        title="Is Structural Variant?",
        description="indicates whether the variant is structural",
    )
    is_annotated: Optional[bool] = Field(
        default=None,
        title="Is Annotated?",
        description="indicates whether functional annotation is available",
    )
    adsp_annotation: Optional[Dict[str, Any]] = Field(
        default=None,
        title="ADSP Annotation",
        description="ADSP-specific annotation data for the variant",
    )
    most_severe_consequence: Optional[Dict[str, Any]] = Field(
        default=None,
        title="Most Severe Consequence",
        description="most severe predicted consequence for the variant",
    )
    functional_annotation: Optional[Dict[str, Any]] = Field(
        default=None,
        title="Functional Annotation",
        description="functional annotation data for the variant",
    )
    allele_frequency: Optional[Dict[str, Any]] = Field(
        default=None,
        title="Allele Frequency",
        description="allele frequency data for the variant",
    )
    ld_partners: Optional[List[Dict[str, Any]]] = Field(
        default=None,
        title="LD Partners",
        description="variants in linkage disequilibrium with this variant",
    )
    functional_annotation_summary: Optional[Dict[str, Any]] = Field(
        default=None,
        title="Functional Annotation Summary",
        description="summary of the variant's functional annotation",
    )

    def __str__(self):
        if self.id is not None:
            return self.id
        else:
            if self.variant_class.is_structural_variant():
                return (
                    f"{self.location.chromosome.value}:{self.location.start}/"
                    f"{self.variant_class}:{self.location.length}"
                )
            else:
                return self.positional_id

    def __resolve_variant_class(self) -> VariantClass:
        len_ref = len(self.ref)
        len_alt = len(self.alt)

        is_SV: bool = len_ref >= 50 or len_alt >= 50

        if is_SV:
            if len_ref == len_alt:
                return VariantClass.LONG_MNV
            elif len_ref == 1 and len_alt > 1:
                return VariantClass.INS
            elif len_ref > 0 and len_alt == 1:
                return VariantClass.DEL
            elif len_ref > 1 and len_alt > 1:
                return VariantClass.INDEL

        elif len_ref == 1 and len_alt == 1:
            return VariantClass.SNV
        elif len_ref == len_alt and len_ref > 1:
            return VariantClass.MNV
        elif len_ref == 1 and len_alt > 1:
            return VariantClass.SHORT_INS
        elif len_ref > 1 and len_alt == 1:
            return VariantClass.SHORT_DEL
        elif len_ref > 1 and len_alt > 1:
            return VariantClass.SHORT_INDEL

    @model_validator(mode="after")
    def resolve_variant_type(self):
        if self.variant_class is not None:
            if VariantClass(self.variant_class).is_indel():
                # resolve to ensure correct resolution of INS, DEL, INDEL
                # otherwise something strange like DUP, CNV or simply SNV/MNV, leave it
                self.variant_class = self.__resolve_variant_class()
        else:
            self.variant_class = self.__resolve_variant_class()

        return self

    @model_validator(mode="after")
    def resolve_length(self):
        return self._resolve_length()

    @property
    def span(self):
        return Range(
            start=self.position, end=self.position + self.length - 1, inclusive_end=1
        )

    @property
    def genomic_region(self):
        return OneBasedGenomicRegion(
            **self.span.model_dump(), chromosome=self.chromosome, length=self.length
        )

    def _resolve_length(self):
        """
        Determine variant length based on type and length of reference allele
        helper function created b/c needs to be done at initialization and then recalculated
        after normalization
        """
        if self.variant_class in [VariantClass.MNV, VariantClass.LONG_MNV]:
            self.length = len(self.ref)
        elif self.variant_class.is_structural_variant() and self.length is None:
            # ideally structural variant length is set, but if not
            self.length = abs(len(self.ref) - len(self.alt))
        elif self.variant_class in [VariantClass.SNV]:
            self.length = 1
        elif self.variant_class == VariantClass.SHORT_INS:
            self.length = len(self.alt) - len(self.ref)
        elif self.variant_class == VariantClass.SHORT_DEL:
            self.length = len(self.ref) - len(self.alt)
        else:  # SHORT_INDEL
            self.length = abs(len(self.ref) - len(self.alt))
        return self

    @classmethod
    def from_positional_id(cls, variant_id: str):
        positional_id = variant_id.replace("-", ":")
        chrm, position, ref, alt = positional_id.split(":")

        return cls(
            chromosome=HumanGenome(chrm),
            position=position,
            ref=ref,
            alt=alt,
            positional_id=positional_id,
            id=positional_id,
        )
