from niagads.enums.core import CaseInsensitiveEnum


class GenomeBuild(CaseInsensitiveEnum):
    """enum for genome builds"""

    GRCh37 = "GRCh37"
    GRCh38 = "GRCh38"

    @classmethod
    def _missing_(cls, value: str):
        """Override super to map hg19 or hg38 to GRCh* nomenclature.
        For everything else call super() to allow case-insensitive matches"""
        if value.lower() == "hg19":
            return cls.GRCh37
        if value.lower() == "hg38":
            return cls.GRCh38
        return super(GenomeBuild, cls)._missing_(value)

    @classmethod
    def list(cls, return_enum_names: bool = False):
        """return a list of the enum values"""
        # FIXME: need hg19, 18 for the enumparameter; check api code
        return super().list(return_enum_names=return_enum_names)  #  + ["hg19", "hg38"]

    def hg_label(self):
        return "hg19" if self.value == "GRCh37" else "hg38"

    # these class methods are from EnumParameters
    # no inheritence here b/c of functional programming
    # and limitations on subclassing Enums
    @classmethod
    def get_description(cls):
        return f"Allowable values are: {','.join(cls.list())}."

    @classmethod
    def validate(cls, value, label: str, returnCls: CaseInsensitiveEnum):
        from niagads.exceptions.core import ValidationError

        # FIXME: sanitize is a API parameter need, should not be here
        # from niagads.api.common.utils import sanitize  # avoid circular import

        try:
            # cls(sanitize(value))
            return returnCls(value)
        except Exception as err:
            raise ValidationError(
                f"Invalid value provided for `{label}`: {value}.  {cls.get_description()}"
            )


class HumanGenome(CaseInsensitiveEnum):
    """Enum representing chromosomes on the primary human assembly.

    Name=chrN, value=N

    str(HumanGenome.chr1) will print the name (chr1)

    includes validator
    """

    chr1 = "1"
    chr2 = "2"
    chr3 = "3"
    chr4 = "4"
    chr5 = "5"
    chr6 = "6"
    chr7 = "7"
    chr8 = "8"
    chr9 = "9"
    chr10 = "10"
    chr11 = "11"
    chr12 = "12"
    chr13 = "13"
    chr14 = "14"
    chr15 = "15"
    chr16 = "16"
    chr17 = "17"
    chr18 = "18"
    chr19 = "19"
    chr20 = "20"
    chr21 = "21"
    chr22 = "22"
    chrX = "X"
    chrY = "Y"
    chrM = "MT"

    # after from https://stackoverflow.com/a/76131490
    @classmethod
    def _missing_(cls, value: str):  # allow 'X' or 'chrX'
        if isinstance(value, str) and value.lower() == "m":
            return cls.chrM
        for member in cls:
            if value == member.name:
                return member
        return super()._missing_(cls, value)

    def __str__(self):
        return self.name

    @classmethod
    def list(cls, return_enum_names: bool = True):
        return super().list(return_enum_names=return_enum_names)

    @classmethod
    def sort_order(self):
        """returns a {chr:order} mapping to faciliate chr based sorting"""
        return {chr: index for index, chr in enumerate(self.__members__)}
