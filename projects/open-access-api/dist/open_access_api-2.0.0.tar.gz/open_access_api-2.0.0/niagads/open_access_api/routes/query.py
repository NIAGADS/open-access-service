"""Natural-language query endpoints for Open Access resources."""

from fastapi import APIRouter, Depends, Query
from niagads.api.common.models.context.request import Parameters
from niagads.api.common.models.context.response import ResponseConfiguration
from niagads.api.common.models.responses.records import RecordResponse
from niagads.api.common.parameters.response.pagination import page_param
from niagads.api.common.services.query import QueryEndpointService
from niagads.common.search.models.record import AnnotatedSearchMatch
from niagads.common.types import Entity
from niagads.open_access_api.dependencies import OpenAccessEndpointContext

router = APIRouter(prefix="/query", tags=["Query"])


async def query_service(
    text: str = Query(description="Natural-language text to search for."),
    limit: int = Query(
        default=10,
        gt=0,
        description="Maximum number of semantic matches per entity type.",
    ),
    page: int = Depends(page_param),
    context: OpenAccessEndpointContext = Depends(),
) -> QueryEndpointService:
    """Configure the query service with request parameters and response models.

    Args:
        text (str): Natural-language search text.
        limit (int): Maximum matches per entity type.
        page (int): One-based response page.
        context (OpenAccessEndpointContext): Request-scoped dependencies.

    Returns:
        QueryEndpointService: Configured semantic query service.
    """
    return QueryEndpointService(
        context=context,
        parameters=Parameters(text=text, limit=limit, page=page),
        response_config=ResponseConfiguration(
            response_model=RecordResponse,
            record_model=AnnotatedSearchMatch,
        ),
    )


@router.get(
    "",
    summary="Query tracks and genes",
    operation_id="queryResources",
    response_model=RecordResponse[AnnotatedSearchMatch],
)
async def query_resources(
    service: QueryEndpointService = Depends(query_service),
) -> RecordResponse[AnnotatedSearchMatch]:
    result = await service.get_cached_response()
    if not result:
        result = await service.semantic_search()
        from_cache = False
    else:
        from_cache = True
    return await service.generate_response(result, from_cache=from_cache)


@router.get(
    "/tracks",
    summary="Query track metadata",
    operation_id="queryTracks",
    response_model=RecordResponse[AnnotatedSearchMatch],
)
async def query_tracks(
    service: QueryEndpointService = Depends(query_service),
) -> RecordResponse[AnnotatedSearchMatch]:
    result = await service.get_cached_response()
    if not result:
        result = await service.semantic_search(Entity.TRACK)
        from_cache = False
    else:
        from_cache = True
    return await service.generate_response(result, from_cache=from_cache)


@router.get(
    "/genes",
    summary="Query gene nomenclature and annotations",
    operation_id="queryGenes",
    response_model=RecordResponse[AnnotatedSearchMatch],
)
async def query_genes(
    service: QueryEndpointService = Depends(query_service),
) -> RecordResponse[AnnotatedSearchMatch]:
    result = await service.get_cached_response()
    if not result:
        result = await service.semantic_search(Entity.GENE)
        from_cache = False
    else:
        from_cache = True
    return await service.generate_response(result, from_cache=from_cache)


@router.get(
    "/variants",
    summary="Query variant annotations",
    operation_id="queryVariants",
    response_model=RecordResponse[AnnotatedSearchMatch],
    openapi_extra={"x-status": "planned"},
)
async def query_variants(
    service: QueryEndpointService = Depends(query_service),
) -> RecordResponse[AnnotatedSearchMatch]:
    return NotImplemented("Coming soon: this search is not yet implemented.")


@router.get(
    "/ontology",
    summary="Query ontology terms",
    description="Search ontology terms and concept labels in a (optional) specific ontology namespace.",
    operation_id="queryOntologyTerms",
    response_model=RecordResponse[AnnotatedSearchMatch],
    openapi_extra={"x-status": "beta"},
)
async def query_ontology_terms(
    service: QueryEndpointService = Depends(query_service),
    namespace: str = Query(
        default="",
        title="Ontology Namespace",
        description=(
            "Optional ontology namespace to scope the query. Common values include "
            "GO, MeSH, MONDO, and HP.  Namespaces are exact (case sensitive) matches"
        ),
        examples=["GO", "MeSH", "MONDO", "HP"],
    ),
) -> RecordResponse[AnnotatedSearchMatch]:
    raise NotImplementedError("Ontology Semantic Search coming soon")
    # TODO: handle namespace parameter
    result = await service.get_cached_response()
    if not result:
        result = await service.semantic_search(Entity.ONTOLOGY_TERM)
        from_cache = False
    else:
        from_cache = True
    return await service.generate_response(result, from_cache=from_cache)
