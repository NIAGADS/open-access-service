from ast import literal_eval
from typing import Any, List, Optional, Union

from niagads.api.common.models.records.mixins import ORMCompatabileMixin
from niagads.api.common.models.records.types import ORMCompatibleRecord
from niagads.common.genomic.features.models import GenomicFeatureType
from niagads.common.track.models import TrackRecord
from niagads.genome_reference.human import GenomeBuild
from pydantic import (
    ConfigDict,
    Field,
    field_serializer,
    field_validator,
    model_validator,
)

# TODO: revise -> creates circular import and can be handled differently
# upon retrieval to by serializing into ontologyterms
# class BiosampleCharacteristicsReport(BiosampleCharacteristics):
#     biosample_type: Optional[List[OntologyTerm]] = Field(
#         default=None,
#         title="Biosample: Type",
#         description="the biological source of a sample used in an experiment",
#     )


class TrackMetadataBrief(ORMCompatibleRecord):
    model_config = ConfigDict(is_summary=True)

    id: str = Field(title="Track ID", description="stable track identifier")
    name: str = Field(title="Name")
    description: Optional[str] = Field(default=None, title="Description")
    genome_build: GenomeBuild = Field(
        default=GenomeBuild.GRCh38,
        title="Genome Build",
        description=f"reference genome build",
    )
    feature_type: Optional[GenomicFeatureType] = Field(
        default=None,
        title="Feature",
        description="primary type of genomic feature being annotated",
    )
    is_download_only: Optional[bool] = Field(
        default=False,
        title="Download Only",
        description="File is available for download only; data cannot be queried using the NIAGADS Open Access API.",
    )
    data_source: Optional[str] = Field(
        default=None,
        title="Data Source",
        description="original data source for the track",
    )
    data_category: Optional[str] = Field(
        default=None,
        title="Category",
        description="data category; may be analysis type",
    )
    url: Optional[str] = Field(
        default=None,
        title="Download URL",
        description="URL for NIAGADS-standardized file",
    )

    @field_serializer("is_download_only")
    def serialize_download_only_boolean(self, is_download_only, _info):
        return self.boolean_null_check(is_download_only)

    @model_validator(mode="before")
    def extract_nested_fields(cls, values: Union[dict, any]):
        """
        Extract nested fields from ORM object and assign to top-level fields.

        Handles both ORM objects and dictionaries, extracting data_source
        from provenance, and url from file_properties.
        """
        if isinstance(values, dict):
            # Handle dictionary input
            provenance = values.get("provenance")
            if isinstance(provenance, dict):
                values.setdefault("data_source", provenance.get("data_source"))
            elif hasattr(provenance, "data_source"):  # ORM object
                values.setdefault("data_source", provenance.data_source)

            file_props = values.get("file_properties")
            if isinstance(file_props, dict):
                values.setdefault("url", file_props.get("url"))
            elif hasattr(file_props, "url"):  # ORM object
                values.setdefault("url", file_props.url)

            experimental_design = values.get("experimental_design")
            if isinstance(experimental_design, dict):
                values.setdefault(
                    "data_category", experimental_design.get("data_category")
                )
            elif hasattr(experimental_design, "data_category"):  # ORM object
                values.setdefault("data_category", experimental_design.data_category)

        return values


class TrackMetadata(TrackRecord, ORMCompatabileMixin):
    id: str = Field(title="Track ID", description="stable track identifier")

    biosample_characteristics: Optional[dict] = Field(
        default=None,
        title="Sample Characteristics",
    )

    # FIXME: Temporary API patch for phenotype lists stored as strings by an
    # outdated ETL serializer. Remove after the stored records are corrected.
    @field_validator("study_diagnosis", mode="before")
    @classmethod
    def parse_study_diagnosis_phenotypes(cls, value: Any) -> Any:
        """Parse stored phenotype list strings before nested validation.

        Args:
            value (Any): Study diagnosis data retrieved for the track.

        Returns:
            Any: Diagnosis data with phenotype strings parsed into lists.
        """
        if not isinstance(value, list):
            return value

        return [
            (
                {**diagnosis, "phenotype": literal_eval(diagnosis["phenotype"])}
                if isinstance(diagnosis, dict)
                and isinstance(diagnosis.get("phenotype"), str)
                else diagnosis
            )
            for diagnosis in value
        ]
