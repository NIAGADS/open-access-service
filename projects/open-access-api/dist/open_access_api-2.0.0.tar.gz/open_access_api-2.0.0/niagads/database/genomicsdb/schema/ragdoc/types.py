from enum import auto

from niagads.enums.core import CaseInsensitiveEnum


class RAGDocType(CaseInsensitiveEnum):
    REFERENCE = auto()
    ONTOLOGY = auto()
    GENE = auto()
    VARIANT = auto()
    METADATA = auto()
    DOCUMENT = auto()


class GeneDocumentSection(CaseInsensitiveEnum):
    IDENTITY = auto()
    STRUCTURE = auto()
    FUNCTIONAL_ANNOTATION = auto()
    MEMBERSHIPS = auto()
    REFERENCES = auto()
